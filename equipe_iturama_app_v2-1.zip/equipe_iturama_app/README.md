# Equipe Iturama — Aplicativo Android

Versão 1.1 do aplicativo baseado no `index.html` original.

## Recursos
- Tela de abertura profissional da Equipe Iturama.
- Abre a versão publicada do sistema automaticamente para receber atualizações do site sem reinstalar o APK.
- Mantém uma cópia local do `index.html` como fallback quando a versão online não estiver disponível.
- JavaScript e armazenamento local habilitados.
- Links de telefone/e-mail funcionam pelo Android.
- Links internos do GitHub Pages continuam dentro do aplicativo.
- Botão Voltar navega dentro do sistema antes de sair.
- Portrait e compatível a partir do Android 6 (API 23).

## URL online configurada
https://leandrofrutal86-a11y.github.io/coberturas-iturama/

## Compilação
Abra a pasta no Android Studio e execute:
Build > Build APK(s)

O APK de debug será gerado em:
app/build/outputs/apk/debug/app-debug.apk
