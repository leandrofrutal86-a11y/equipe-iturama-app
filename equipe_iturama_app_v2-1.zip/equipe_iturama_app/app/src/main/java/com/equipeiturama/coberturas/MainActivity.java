package com.equipeiturama.coberturas;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final String REMOTE_URL = "https://leandrofrutal86-a11y.github.io/coberturas-iturama/";
    private WebView webView;
    private View splash;
    private boolean remoteFailed = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(183,14,20));
        w.setNavigationBarColor(Color.rgb(22,22,22));
        showSplash();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,246,248));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (splash != null) {
                    new Handler().postDelayed(() -> hideSplash(), 250);
                }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && !remoteFailed) {
                    remoteFailed = true;
                    view.loadUrl("file:///android_asset/index.html");
                }
            }
        });

        setContentView(webView);
        new Handler().postDelayed(() -> {
            if (!remoteFailed) webView.loadUrl(REMOTE_URL);
        }, 850);
    }

    private boolean handleUrl(Uri u) {
        String scheme = u.getScheme();
        if (scheme == null) return false;
        if ("tel".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
            return true;
        }
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            String host = u.getHost();
            if (host != null && (host.equalsIgnoreCase("leandrofrutal86-a11y.github.io") || host.endsWith(".github.io"))) {
                return false;
            }
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
            return true;
        }
        return false;
    }

    private void showSplash() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.rgb(215,25,32));
        box.setPadding(32,32,32,32);

        android.widget.ImageView logo = new android.widget.ImageView(this);
        logo.setImageResource(com.equipeiturama.coberturas.R.drawable.splash_logo);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(130,130);
        lp.bottomMargin = 24;
        box.addView(logo, lp);

        TextView title = new TextView(this);
        title.setText("EQUIPE ITURAMA");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1,-2));

        TextView sub = new TextView(this);
        sub.setText("Coberturas e Gestão Comercial");
        sub.setTextColor(Color.WHITE);
        sub.setAlpha(.9f);
        sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin = 6;
        box.addView(sub, sp);

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(42,42);
        pp.topMargin = 28;
        box.addView(progress, pp);
        splash = box;
        setContentView(splash);
    }

    private void hideSplash() {
        if (splash != null) {
            splash.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                splash.setVisibility(View.GONE);
                splash = null;
            }).start();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
